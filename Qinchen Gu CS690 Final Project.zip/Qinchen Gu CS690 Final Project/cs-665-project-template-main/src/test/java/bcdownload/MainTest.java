package bcdownload;

import bcdownload.RestaurantFacade;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class MainTest {
    private final PrintStream originalOut = System.out;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    @BeforeEach
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
    }

    @AfterEach
    public void restoreStreams() {
        System.setOut(originalOut);
    }

    @Test
    public void testBreakfastOrder() {
        RestaurantFacade facade = new RestaurantFacade();
        facade.showMenuAndTakeOrder("breakfast");
        String output = outContent.toString();
        assertTrue(output.contains("Breakfast Menu:"));
        assertTrue(output.contains("Order received for: Pancakes"));
    }

    @Test
    public void testDinnerOrder() {
        RestaurantFacade facade = new RestaurantFacade();
        facade.showMenuAndTakeOrder( "dinner");
        String output = outContent.toString();
        assertTrue(output.contains("Order received for: Steak"));
        assertTrue(output.contains("Dinner Menu:"));
    }

    @Test
    public void testDefaultOrder() {
        RestaurantFacade facade = new RestaurantFacade();
        facade.showMenuAndTakeOrder( "default");
        String output = outContent.toString();
        assertTrue(output.contains("Order received for: Pizza"));
        assertTrue(output.contains("Default Menu:"));
    }
}
