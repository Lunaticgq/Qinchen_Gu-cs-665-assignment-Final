package bcdownload;

// Concrete implementation of a default menu
class DefaultMenu extends Menu {
    public void display() {
        System.out.println("Default Menu:");
        System.out.println("1. Pizza");
        System.out.println("2. Burger");
        System.out.println("3. Pasta");
    }

    public MenuItem getItem(String itemName) {
        String orderResult = itemName;
        if (!itemName.equals("Pizza") && !itemName.equals("Burger") && !itemName.equals("Pasta")) {
            orderResult += ", however we don't have this item in the menu right now.";
        }
        return new MenuItem(orderResult);
    }
}

// Concrete implementation of a breakfast menu
class BreakfastMenu extends Menu {

    public void display() {
        System.out.println("Breakfast Menu:");
        System.out.println("1. Pancakes");
        System.out.println("2. Omelette");
        System.out.println("3. Cereal");
    }

    public MenuItem getItem(String itemName) {
        // if the item is not in the menu, return order name+ ", however we don't have this item in the menu right now."
        String orderResult = itemName;
        if (!itemName.equals("Pancakes") && !itemName.equals("Omelette") && !itemName.equals("Cereal")) {
            orderResult += ", however we don't have this item in the menu right now.";
        }

        return new MenuItem(orderResult);
    }

}

// Concrete implementation of a dinner menu
class DinnerMenu extends Menu {
    public void display() {
        System.out.println("Dinner Menu:");
        System.out.println("1. Steak");
        System.out.println("2. Salmon");
        System.out.println("3. Pasta");
    }

    public MenuItem getItem(String itemName) {
        String orderResult = itemName;
        if (!itemName.equals("Steak") && !itemName.equals("Salmon") && !itemName.equals("Pasta")) {
            orderResult += ", however we don't have this item in the menu right now.";
        }
        return new MenuItem(orderResult);
    }
}
