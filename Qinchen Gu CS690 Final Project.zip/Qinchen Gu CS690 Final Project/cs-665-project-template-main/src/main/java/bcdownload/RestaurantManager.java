package bcdownload;
import java.util.Scanner;

import java.util.Objects;

// Singleton Pattern: The RestaurantManager is a singleton class.
public class RestaurantManager {
    private static RestaurantManager instance;

    private RestaurantManager() {}

    public static synchronized RestaurantManager getInstance() {
        if (instance == null) {
            instance = new RestaurantManager();
        }
        return instance;
    }

    public void displayMenu(String menuType) {
        Menu menu = Objects.requireNonNull(MenuFactory.getMenuFactory(menuType)).getMenu();
        menu.display();
    }

    public void takeOrder(String menuType) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter the dish name: ");
        String dishName = scanner.nextLine();
        Menu menu = Objects.requireNonNull(MenuFactory.getMenuFactory(menuType)).getMenu();
        MenuItem item = menu.getItem(dishName);
        System.out.println("Order received for: " + item.getName());
    }
}
