package bcdownload;

// Abstract Factory for creating menus
abstract class MenuFactory {
    public static MenuFactory getMenuFactory(String type) {
        switch (type) {
            case "default":
                return new DefaultMenuFactory();
            case "breakfast":
                return new BreakfastMenuFactory();
            case "dinner":
                return new DinnerMenuFactory();
            default:
                return null;
        }
    }

    abstract Menu getMenu();
}

// Concrete Factory for default menu
class DefaultMenuFactory extends MenuFactory {
    @Override
    Menu getMenu() {
        return new DefaultMenu();
    }
}

// Concrete Factory for breakfast menu
class BreakfastMenuFactory extends MenuFactory {
    @Override
    Menu getMenu() {
        return new BreakfastMenu();
    }
}

// Concrete Factory for dinner menu
class DinnerMenuFactory extends MenuFactory {
    @Override
    Menu getMenu() {
        return new DinnerMenu();
    }
}


