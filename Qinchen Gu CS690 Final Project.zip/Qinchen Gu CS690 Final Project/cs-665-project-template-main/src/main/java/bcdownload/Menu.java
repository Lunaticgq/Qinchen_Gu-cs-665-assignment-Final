package bcdownload;

// Menu interface
abstract class Menu {
    public abstract void display();
    public abstract MenuItem getItem(String itemName);
}



// Simple MenuItem class
class MenuItem {
    private String name;

    public MenuItem(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
