package bcdownload;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        RestaurantFacade facade = new RestaurantFacade();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Please enter the time (0-23), or -1 to exit: ");
            int time = scanner.nextInt();

            if (time == -1) {
                break;
            }


            if (time < 12) {
                facade.showMenuAndTakeOrder( "breakfast");
            } else if (time > 17) {
                facade.showMenuAndTakeOrder( "dinner");
            } else {
                facade.showMenuAndTakeOrder("default");
            }
        }

        scanner.close();
    }
}
