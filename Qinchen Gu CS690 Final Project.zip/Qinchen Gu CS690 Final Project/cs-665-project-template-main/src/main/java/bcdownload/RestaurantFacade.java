package bcdownload;

// Facade Pattern: RestaurantFacade provides a simplified interface
public class RestaurantFacade {
    private RestaurantManager manager;

    public RestaurantFacade() {
        this.manager = RestaurantManager.getInstance();
    }

    public void showMenuAndTakeOrder(String menuType) {
        manager.displayMenu(menuType);
        manager.takeOrder(menuType);
    }
}
